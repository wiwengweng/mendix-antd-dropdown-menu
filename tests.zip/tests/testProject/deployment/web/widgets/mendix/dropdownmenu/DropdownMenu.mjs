
(function(l, r) { if (!l || l.getElementById('livereloadscript')) return; r = l.createElement('script'); r.async = 1; r.src = '//' + (self.location.host || 'localhost').split(':')[0] + ':35730/livereload.js?snipver=1'; r.id = 'livereloadscript'; l.getElementsByTagName('head')[0].appendChild(r) })(self.document);
import { Component, createElement } from 'react';

class HelloWorldSample extends Component {
    render() {
        return createElement("div", { className: "widget-hello-world" },
            "Hello ",
            this.props.sampleText);
    }
}

class DropdownMenu extends Component {
    render() {
        return createElement(HelloWorldSample, { sampleText: this.props.sampleText ? this.props.sampleText : "World" });
    }
}

export { DropdownMenu };
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRHJvcGRvd25NZW51Lm1qcyIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL2NvbXBvbmVudHMvSGVsbG9Xb3JsZFNhbXBsZS50c3giLCIuLi8uLi8uLi8uLi8uLi9zcmMvRHJvcGRvd25NZW51LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIFJlYWN0Tm9kZSwgY3JlYXRlRWxlbWVudCB9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgaW50ZXJmYWNlIEhlbGxvV29ybGRTYW1wbGVQcm9wcyB7XG4gICAgc2FtcGxlVGV4dD86IHN0cmluZztcbn1cblxuZXhwb3J0IGNsYXNzIEhlbGxvV29ybGRTYW1wbGUgZXh0ZW5kcyBDb21wb25lbnQ8SGVsbG9Xb3JsZFNhbXBsZVByb3BzPiB7XG4gICAgcmVuZGVyKCk6IFJlYWN0Tm9kZSB7XG4gICAgICAgIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cIndpZGdldC1oZWxsby13b3JsZFwiPkhlbGxvIHt0aGlzLnByb3BzLnNhbXBsZVRleHR9PC9kaXY+O1xuICAgIH1cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgUmVhY3ROb2RlLCBjcmVhdGVFbGVtZW50IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBIZWxsb1dvcmxkU2FtcGxlIH0gZnJvbSBcIi4vY29tcG9uZW50cy9IZWxsb1dvcmxkU2FtcGxlXCI7XG5cbmltcG9ydCB7IERyb3Bkb3duTWVudUNvbnRhaW5lclByb3BzIH0gZnJvbSBcIi4uL3R5cGluZ3MvRHJvcGRvd25NZW51UHJvcHNcIjtcblxuaW1wb3J0IFwiLi91aS9Ecm9wZG93bk1lbnUuY3NzXCI7XG5cbmV4cG9ydCBjbGFzcyBEcm9wZG93bk1lbnUgZXh0ZW5kcyBDb21wb25lbnQ8RHJvcGRvd25NZW51Q29udGFpbmVyUHJvcHM+IHtcbiAgICByZW5kZXIoKTogUmVhY3ROb2RlIHtcbiAgICAgICAgcmV0dXJuIDxIZWxsb1dvcmxkU2FtcGxlIHNhbXBsZVRleHQ9e3RoaXMucHJvcHMuc2FtcGxlVGV4dCA/IHRoaXMucHJvcHMuc2FtcGxlVGV4dCA6IFwiV29ybGRcIn0gLz47XG4gICAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7QUFNTSxNQUFPLGdCQUFpQixTQUFRLFNBQWdDLENBQUE7SUFDbEUsTUFBTSxHQUFBO1FBQ0YsT0FBTyxhQUFBLENBQUEsS0FBQSxFQUFBLEVBQUssU0FBUyxFQUFDLG9CQUFvQixFQUFBOztBQUFRLFlBQUEsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQU8sQ0FBQztLQUNsRjtBQUNKOztBQ0hLLE1BQU8sWUFBYSxTQUFRLFNBQXFDLENBQUE7SUFDbkUsTUFBTSxHQUFBO1FBQ0YsT0FBTyxhQUFBLENBQUMsZ0JBQWdCLEVBQUMsRUFBQSxVQUFVLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLEdBQUcsT0FBTyxFQUFBLENBQUksQ0FBQztLQUNwRztBQUNKOzs7OyJ9
