
(function(l, r) { if (!l || l.getElementById('livereloadscript')) return; r = l.createElement('script'); r.async = 1; r.src = '//' + (self.location.host || 'localhost').split(':')[0] + ':35729/livereload.js?snipver=1'; r.id = 'livereloadscript'; l.getElementsByTagName('head')[0].appendChild(r) })(self.document);
define(['exports', 'react'], (function (exports, react) { 'use strict';

    class HelloWorldSample extends react.Component {
        render() {
            return react.createElement("div", { className: "widget-hello-world" },
                "Hello ",
                this.props.sampleText);
        }
    }

    class DropdownMenu extends react.Component {
        render() {
            return react.createElement(HelloWorldSample, { sampleText: this.props.sampleText ? this.props.sampleText : "World" });
        }
    }

    exports.DropdownMenu = DropdownMenu;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRHJvcGRvd25NZW51LmpzIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvY29tcG9uZW50cy9IZWxsb1dvcmxkU2FtcGxlLnRzeCIsIi4uLy4uLy4uLy4uLy4uL3NyYy9Ecm9wZG93bk1lbnUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgUmVhY3ROb2RlLCBjcmVhdGVFbGVtZW50IH0gZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgSGVsbG9Xb3JsZFNhbXBsZVByb3BzIHtcbiAgICBzYW1wbGVUZXh0Pzogc3RyaW5nO1xufVxuXG5leHBvcnQgY2xhc3MgSGVsbG9Xb3JsZFNhbXBsZSBleHRlbmRzIENvbXBvbmVudDxIZWxsb1dvcmxkU2FtcGxlUHJvcHM+IHtcbiAgICByZW5kZXIoKTogUmVhY3ROb2RlIHtcbiAgICAgICAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwid2lkZ2V0LWhlbGxvLXdvcmxkXCI+SGVsbG8ge3RoaXMucHJvcHMuc2FtcGxlVGV4dH08L2Rpdj47XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgQ29tcG9uZW50LCBSZWFjdE5vZGUsIGNyZWF0ZUVsZW1lbnQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEhlbGxvV29ybGRTYW1wbGUgfSBmcm9tIFwiLi9jb21wb25lbnRzL0hlbGxvV29ybGRTYW1wbGVcIjtcblxuaW1wb3J0IHsgRHJvcGRvd25NZW51Q29udGFpbmVyUHJvcHMgfSBmcm9tIFwiLi4vdHlwaW5ncy9Ecm9wZG93bk1lbnVQcm9wc1wiO1xuXG5pbXBvcnQgXCIuL3VpL0Ryb3Bkb3duTWVudS5jc3NcIjtcblxuZXhwb3J0IGNsYXNzIERyb3Bkb3duTWVudSBleHRlbmRzIENvbXBvbmVudDxEcm9wZG93bk1lbnVDb250YWluZXJQcm9wcz4ge1xuICAgIHJlbmRlcigpOiBSZWFjdE5vZGUge1xuICAgICAgICByZXR1cm4gPEhlbGxvV29ybGRTYW1wbGUgc2FtcGxlVGV4dD17dGhpcy5wcm9wcy5zYW1wbGVUZXh0ID8gdGhpcy5wcm9wcy5zYW1wbGVUZXh0IDogXCJXb3JsZFwifSAvPjtcbiAgICB9XG59XG4iXSwibmFtZXMiOlsiQ29tcG9uZW50IiwiY3JlYXRlRWxlbWVudCJdLCJtYXBwaW5ncyI6Ijs7OztJQU1NLE1BQU8sZ0JBQWlCLFNBQVFBLGVBQWdDLENBQUE7UUFDbEUsTUFBTSxHQUFBO1lBQ0YsT0FBT0MsbUJBQUEsQ0FBQSxLQUFBLEVBQUEsRUFBSyxTQUFTLEVBQUMsb0JBQW9CLEVBQUE7O0lBQVEsWUFBQSxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBTyxDQUFDO1NBQ2xGO0lBQ0o7O0lDSEssTUFBTyxZQUFhLFNBQVFELGVBQXFDLENBQUE7UUFDbkUsTUFBTSxHQUFBO1lBQ0YsT0FBT0MsbUJBQUEsQ0FBQyxnQkFBZ0IsRUFBQyxFQUFBLFVBQVUsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxPQUFPLEVBQUEsQ0FBSSxDQUFDO1NBQ3BHO0lBQ0o7Ozs7Ozs7Ozs7In0=
