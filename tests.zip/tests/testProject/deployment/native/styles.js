import * as style0 from "D:/Projects/reactProjects/CustomWidgets/textBox/tests/testProject/themesource/nanoflowcommons/native/main";
import * as style1 from "D:/Projects/reactProjects/CustomWidgets/textBox/tests/testProject/themesource/webactions/native/main";
import * as style2 from "D:/Projects/reactProjects/CustomWidgets/textBox/tests/testProject/themesource/atlas_core/native/main";
import * as style3 from "D:/Projects/reactProjects/CustomWidgets/textBox/tests/testProject/themesource/myfirstmodule/native/main";
import * as style4 from "D:/Projects/reactProjects/CustomWidgets/textBox/tests/testProject/theme/native/main";

import { flatten } from "mendix/native";

module.exports = flatten([style0, style1, style2, style3, style4]);
